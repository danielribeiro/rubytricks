<#-- This is a FreeMarker template -->
<#assign licensePrefix = "# ">
<#include "../Licenses/license-${project.license}.txt">

<#-- the file to require variable here can be a path to spec_helper (if it exists) -->
<#-- or the name of the tested file. quoting is handled in RubyTargetChooserPanel -->
$LOAD_PATH.unshift File.join(File.dirname(__FILE__),'..','lib')
require ${file_to_require}

describe ${classname} do
  before(:each) do
    @${classfield} = ${classname}.new
  end

  it "should desc" do
    # TODO
  end
end

